cadena="Hola Mundo!"
print(cadena)